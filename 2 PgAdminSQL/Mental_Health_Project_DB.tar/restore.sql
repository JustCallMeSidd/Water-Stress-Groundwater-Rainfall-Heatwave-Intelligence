--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 18.3
-- Dumped by pg_dump version 18.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Mental_Health_project_DB";
--
-- Name: Mental_Health_project_DB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Mental_Health_project_DB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_India.1252';


ALTER DATABASE "Mental_Health_project_DB" OWNER TO postgres;

\unrestrict (null)
\connect "Mental_Health_project_DB"
\restrict (null)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: lifestyle_habits; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lifestyle_habits (
    lifestyle_id integer NOT NULL,
    respondent_id integer,
    work_study_hrs character varying(50),
    sleep_hrs character varying(50),
    physical_activity_days character varying(50),
    screen_time character varying(50),
    outings_freq character varying(50),
    sleep_quality integer,
    socialmedia_mood integer,
    regular_breaks character varying(10),
    has_coping_strategy character varying(10)
);


ALTER TABLE public.lifestyle_habits OWNER TO postgres;

--
-- Name: mental_health_assessment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mental_health_assessment (
    assessment_id integer NOT NULL,
    respondent_id integer,
    low_interest character varying(20),
    depressed character varying(20),
    sleep_trouble character varying(20),
    low_energy character varying(20),
    poor_concentration character varying(20),
    anxiety character varying(20),
    emotional_drain character varying(20),
    stress_level integer,
    burnout character varying(20),
    work_pressure character varying(20),
    wl_balance character varying(20),
    life_control character varying(20),
    family_support character varying(20),
    coping_mechanism character varying(100),
    therapist_consult character varying(20),
    social_support character varying(20),
    mh_affected character varying(20)
);


ALTER TABLE public.mental_health_assessment OWNER TO postgres;

--
-- Name: respondent; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.respondent (
    respondent_id integer NOT NULL,
    age integer,
    gender character varying(20),
    state character varying(100),
    role character varying(100)
);


ALTER TABLE public.respondent OWNER TO postgres;

--
-- Data for Name: lifestyle_habits; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lifestyle_habits (lifestyle_id, respondent_id, work_study_hrs, sleep_hrs, physical_activity_days, screen_time, outings_freq, sleep_quality, socialmedia_mood, regular_breaks, has_coping_strategy) FROM stdin;
\.
COPY public.lifestyle_habits (lifestyle_id, respondent_id, work_study_hrs, sleep_hrs, physical_activity_days, screen_time, outings_freq, sleep_quality, socialmedia_mood, regular_breaks, has_coping_strategy) FROM '$$PATH$$/5020.dat';

--
-- Data for Name: mental_health_assessment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mental_health_assessment (assessment_id, respondent_id, low_interest, depressed, sleep_trouble, low_energy, poor_concentration, anxiety, emotional_drain, stress_level, burnout, work_pressure, wl_balance, life_control, family_support, coping_mechanism, therapist_consult, social_support, mh_affected) FROM stdin;
\.
COPY public.mental_health_assessment (assessment_id, respondent_id, low_interest, depressed, sleep_trouble, low_energy, poor_concentration, anxiety, emotional_drain, stress_level, burnout, work_pressure, wl_balance, life_control, family_support, coping_mechanism, therapist_consult, social_support, mh_affected) FROM '$$PATH$$/5019.dat';

--
-- Data for Name: respondent; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.respondent (respondent_id, age, gender, state, role) FROM stdin;
\.
COPY public.respondent (respondent_id, age, gender, state, role) FROM '$$PATH$$/5018.dat';

--
-- Name: lifestyle_habits lifestyle_habits_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lifestyle_habits
    ADD CONSTRAINT lifestyle_habits_pkey PRIMARY KEY (lifestyle_id);


--
-- Name: mental_health_assessment mental_health_assessment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mental_health_assessment
    ADD CONSTRAINT mental_health_assessment_pkey PRIMARY KEY (assessment_id);


--
-- Name: respondent respondent_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.respondent
    ADD CONSTRAINT respondent_pkey PRIMARY KEY (respondent_id);


--
-- Name: mental_health_assessment fk_mha_respondent; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mental_health_assessment
    ADD CONSTRAINT fk_mha_respondent FOREIGN KEY (respondent_id) REFERENCES public.respondent(respondent_id);


--
-- Name: lifestyle_habits lifestyle_habits_respondent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lifestyle_habits
    ADD CONSTRAINT lifestyle_habits_respondent_id_fkey FOREIGN KEY (respondent_id) REFERENCES public.respondent(respondent_id);


--
-- PostgreSQL database dump complete
--

